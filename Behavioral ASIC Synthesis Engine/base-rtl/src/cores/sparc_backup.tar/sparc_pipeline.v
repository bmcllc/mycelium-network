// SPARC 5-Stage Pipeline with Delay Slot
// Stages: IF -> ID -> EX -> MEM -> WB
// Big-endian, flat 32 registers, branch delay slot

module sparc_pipeline #(
    parameter IMEM_DEPTH = 256,
    parameter DMEM_DEPTH = 256
) (
    input  wire         clk,
    input  wire         rst,
    output wire [31:0]  pc_o,
    output wire [31:0]  gpr_v0,   // %o0 for result checking
    output wire [3:0]   icc_o,    // condition codes
    output wire         done_o,
    // Debug
    output wire         dbg_pc_write,
    output wire         dbg_stall,
    output wire         dbg_if_id_write,
    output wire         dbg_id_ex_flush,
    output wire         dbg_id_ex_valid,
    output wire         dbg_ex_mem_valid,
    output wire         dbg_mem_wb_valid,
    output wire [4:0]   dbg_id_ex_rd,
    output wire [4:0]   dbg_ex_mem_rd,
    output wire         dbg_wb_write,
    output wire [4:0]   dbg_wb_rd,
    output wire [31:0]  dbg_wb_data,
    output wire [31:0]  dbg_wb_instr
);

    // ============================================================
    // PIPELINE REGISTERS
    // ============================================================

    // IF/ID
    reg [31:0] if_id_pc;
    reg [31:0] if_id_instr;
    reg        if_id_valid;

    // ID/EX
    reg [31:0] id_ex_pc;
    reg [31:0] id_ex_rs1_val;
    reg [31:0] id_ex_rs2_val;
    reg [31:0] id_ex_imm;
    reg [4:0]  id_ex_rs1;
    reg [4:0]  id_ex_rs2;
    reg [4:0]  id_ex_rd;
    reg [5:0]  id_ex_opcode;
    reg [5:0]  id_ex_op3;
    reg        id_ex_i_bit;
    reg        id_ex_reg_write;
    reg        id_ex_mem_read;
    reg        id_ex_mem_write;
    reg        id_ex_mem_to_reg;
    reg        id_ex_is_branch;
    reg        id_ex_is_call;
    reg        id_ex_is_ret;
    reg        id_ex_valid;

    // EX/MEM
    reg [31:0] ex_mem_alu_result;
    reg [31:0] ex_mem_rs2_val;
    reg [4:0]  ex_mem_rd;
    reg [5:0]  ex_mem_opcode;
    reg [5:0]  ex_mem_op3;
    reg        ex_mem_reg_write;
    reg        ex_mem_mem_read;
    reg        ex_mem_mem_write;
    reg        ex_mem_mem_to_reg;
    reg [3:0]  ex_mem_icc;
    reg        ex_mem_is_branch;
    reg        ex_mem_branch_taken;
    reg [31:0] ex_mem_branch_target;
    reg [31:0] ex_mem_pc;
    reg        ex_mem_valid;

    // MEM/WB
    reg [31:0] mem_wb_write_data;
    reg [4:0]  mem_wb_rd;
    reg        mem_wb_reg_write;
    reg [31:0] mem_wb_instr;
    reg        mem_wb_valid;

    // ============================================================
    // REGISTER FILE (flat 32 registers, %g0 hardwired to 0)
    // ============================================================
    reg [31:0] gpr [0:31];
    reg [3:0]  icc; // Z, N, C, V

    // ============================================================
    // INSTRUCTION MEMORY (big-endian)
    // ============================================================
    reg [31:0] imem [0:IMEM_DEPTH-1];

    // ============================================================
    // DATA MEMORY
    // ============================================================
    reg [31:0] dmem [0:DMEM_DEPTH-1];

    // ============================================================
    // PC REGISTER
    // ============================================================
    reg [31:0] pc;

    // ============================================================
    // CONTROL SIGNALS
    // ============================================================
    wire       pc_write;
    wire       if_id_write;
    wire       if_id_flush;
    wire       id_ex_flush;
    wire       stall;
    wire       delay_valid;
    wire       delay_taken;
    wire [31:0] delay_pc;
    wire [31:0] delay_instr;

    // ============================================================
    // HAZARD DETECTION
    // ============================================================
    wire        id_branch_taken;
    wire [5:0]  id_opcode = if_id_instr[31:26];
    wire [4:0]  id_rs1    = if_id_instr[25:21];
    wire [4:0]  id_rs2    = if_id_instr[14:10];

    sparc_hazard hazard_unit (
        .clk(clk), .rst(rst),
        .id_opcode(id_opcode), .id_rs1(id_rs1), .id_rs2(id_rs2),
        .id_is_branch(1'b0), // will be set in ID stage
        .ex_opcode(id_ex_opcode), .ex_rd(id_ex_rd),
        .ex_mem_read(id_ex_mem_read), .ex_reg_write(id_ex_reg_write),
        .mem_rd(ex_mem_rd), .mem_reg_write(ex_mem_reg_write),
        .wb_rd(mem_wb_rd), .wb_reg_write(mem_wb_reg_write),
        .delay_valid(delay_valid),
        .pc_write(pc_write), .if_id_write(if_id_write),
        .if_id_flush(if_id_flush), .id_ex_flush(id_ex_flush), .stall(stall)
    );

    // ============================================================
    // FORWARDING UNIT
    // ============================================================
    wire [1:0] forward_rs1, forward_rs2;

    sparc_forwarding forward_unit (
        .clk(clk), .rst(rst),
        .id_ex_rs1(id_ex_rs1), .id_ex_rs2(id_ex_rs2),
        .ex_mem_rd(ex_mem_rd), .ex_mem_reg_write(ex_mem_reg_write),
        .mem_wb_rd(mem_wb_rd), .mem_wb_reg_write(mem_wb_reg_write),
        .forward_rs1(forward_rs1), .forward_rs2(forward_rs2)
    );

    // ============================================================
    // DELAY SLOT HANDLER
    // ============================================================
    sparc_delay delay_unit (
        .clk(clk), .rst(rst),
        .branch_taken(delay_taken),
        .delay_instr(if_id_instr),
        .delay_pc(if_id_pc),
        .delay_valid(delay_valid),
        .delay_pc_out(delay_pc),
        .delay_instr_out(delay_instr)
    );

    // ============================================================
    // IF STAGE - Instruction Fetch (big-endian)
    // ============================================================
    wire [31:0] pc_plus4 = pc + 32'd4;
    wire [31:0] pc_next = (delay_valid && delay_taken) ? delay_pc : 
                          (id_branch_taken ? ex_mem_branch_target : pc_plus4);

    always @(posedge clk) begin
        if (rst) begin
            pc <= 32'h0000_0000;
        end else if (pc_write) begin
            pc <= pc_next;
        end
    end

    // IF/ID pipeline register
    always @(posedge clk) begin
        if (rst) begin
            if_id_pc     <= 32'h0;
            if_id_instr  <= 32'h0;
            if_id_valid  <= 1'b0;
        end else if (if_id_write) begin
            if_id_pc     <= pc;
            if_id_instr  <= imem[pc[9:2]]; // big-endian: pc[9:2] for word index
            if_id_valid  <= 1'b1;
        end else if (if_id_flush) begin
            if_id_valid  <= 1'b0;
        end
    end

    // ============================================================
    // ID STAGE - Instruction Decode / Register Fetch
    // ============================================================
    wire [5:0]  opcode = if_id_instr[31:26];
    wire [4:0]  rd     = if_id_instr[29:25];
    wire [5:0]  op3    = if_id_instr[24:19];
    wire [4:0]  rs1    = if_id_instr[18:14];
    wire        i_bit  = if_id_instr[13];
    wire [4:0]  rs2    = if_id_instr[4:0];
    wire [12:0] simm13 = if_id_instr[12:0];
    wire [31:0] sext_imm = {{19{simm13[12]}}, simm13};

    // Register file read
    wire [31:0] rs1_val_rf = gpr[rs1];
    wire [31:0] rs2_val_rf = gpr[rs2];

    // Forwarding for register reads in ID stage
    wire rs1_ex_hazard = ex_mem_reg_write && ex_mem_valid && (ex_mem_rd != 5'd0) && (ex_mem_rd == rs1);
    wire rs2_ex_hazard = ex_mem_reg_write && ex_mem_valid && (ex_mem_rd != 5.d0) && (ex_mem_rd == rs2);
    wire rs1_mem_hazard = mem_wb_reg_write && mem_wb_valid && (mem_wb_rd != 5'd0) && (mem_wb_rd == rs1);
    wire rs2_mem_hazard = mem_wb_reg_write && mem_wb_valid && (mem_wb_rd != 5.d0) && (mem_wb_rd == rs2);

    wire [31:0] rs1_val = rs1_ex_hazard ? ex_mem_alu_result :
                          rs1_mem_hazard ? mem_wb_write_data :
                          rs1_val_rf;
    wire [31:0] rs2_val = rs2_ex_hazard ? ex_mem_alu_result :
                          rs2_mem_hazard ? mem_wb_write_data :
                          rs2_val_rf;

    // Branch condition evaluation
    wire branch_cond = (opcode == 6'h04) ? icc[3] :  // be: Z=1
                       (opcode == 6'h05) ? ~icc[3] :  // bne: Z=0
                       (opcode == 6'h01) ? icc[2] :   // bl: N=1
                       (opcode == 6'h02) ? ~icc[2] :  // bge: N=0
                       (opcode == 6'h06) ? (icc[2] | icc[3]) : // ble: N or Z
                       (opcode == 6'h07) ? ~(icc[2] | icc[3]) : // bg: not (N or Z)
                       1'b0;

    assign id_branch_taken = if_id_valid && (opcode == 6'h01 || opcode == 6'h02 || 
        opcode == 6'h04 || opcode == 6'h05 || opcode == 6'h06 || opcode == 6'h07) && branch_cond;

    // CALL/JMPL detection
    wire id_is_call = if_id_valid && (opcode == 6'h01); // CALL
    wire id_is_ret  = if_id_valid && (opcode == 6'h02) && (op3 == 6'h38); // JMPL %o7+8, %g0 (ret)
    wire id_is_jmpl = if_id_valid && (opcode == 6'h02) && (op3 == 6'h38); // JMPL

    // Control signal generation
    reg id_reg_write, id_mem_read, id_mem_write, id_mem_to_reg;
    reg id_is_branch, id_is_call;

    always @(*) begin
        id_reg_write  = 1'b0;
        id_mem_read   = 1'b0;
        id_mem_write  = 1'b0;
        id_mem_to_reg = 1'b0;
        id_is_branch  = 1'b0;
        id_is_call    = 1'b0;

        if (if_id_valid) begin
case (opcode)
    6'h02: begin // R-type
        case (op3)
            6'h10: begin id_reg_write = 1'b1; end // ADDcc
            6'h14: begin id_reg_write = 1'b1; end // SUBcc
            6'h38: begin id_is_call = 1'b1; id_reg_write = 1'b1; end // JMPL (call/ret)
            default: begin id_reg_write = 1'b1; end // other R-type
        endcase
        6'h03: begin id_reg_write = 1'b1; id_is_call = 1'b1; end // CALL
        6'h01, 6'h02, 6'h03, 6'h04, 6'h05, 6'h06, 6'h07: begin id_is_branch = 1'b1; end // branches
    end
end
                6'h03: begin id_reg_write = 1'b1; id_is_call = 1'b1; end // CALL
                6'h01, 6'h02, 6'h03, 6'h04, 6'h05, 6'h06, 6'h07: begin id_is_branch = 1'b1; end // branches
                6'h0C: begin id_reg_write = 1'b1; end // SETHI
                6'h08: begin id_reg_write = 1'b1; end // LD (op3=0)
                6'h0A: begin id_mem_read = 1'b1; id_mem_to_reg = 1'b1; id_reg_write = 1'b1; end // LD
                6'h0C: begin id_mem_read = 1'b1; id_mem_to_reg = 1'b1; id_reg_write = 1'b1; end // LD
                6'h0E: begin id_mem_write = 1'b1; end // ST
                6'h0F: begin id_mem_write = 1'b1; end // ST
                default: ;
            endcase
        end
    end

    // ID/EX pipeline register
    always @(posedge clk) begin
        if (rst || id_ex_flush) begin
            id_ex_pc         <= 32'h0;
            id_ex_rs1_val    <= 32'h0;
            id_ex_rs2_val    <= 32'h0;
            id_ex_imm        <= 32'h0;
            id_ex_rs1        <= 5'h0;
            id_ex_rs2        <= 5'h0;
            id_ex_rd         <= 5'h0;
            id_ex_opcode     <= 6'h0;
            id_ex_op3        <= 6'h0;
            id_ex_i_bit      <= 1'b0;
            id_ex_reg_write  <= 1'b0;
            id_ex_mem_read   <= 1'b0;
            id_ex_mem_write  <= 1'b0;
            id_ex_mem_to_reg <= 1'b0;
            id_ex_is_branch  <= 1'b0;
            id_ex_is_call    <= 1'b0;
            id_ex_is_ret     <= 1'b0;
            id_ex_valid      <= 1'b0;
        end else begin
            id_ex_pc         <= if_id_pc;
            id_ex_rs1_val    <= rs1_val;
            id_ex_rs2_val    <= rs2_val;
            id_ex_imm        <= sext_imm;
            id_ex_rs1        <= rs1;
            id_ex_rs2        <= rs2;
            id_ex_rd         <= rd;
            id_ex_opcode     <= opcode;
            id_ex_op3        <= op3;
            id_ex_i_bit      <= i_bit;
            id_ex_reg_write  <= id_reg_write && if_id_valid;
            id_ex_mem_read   <= id_mem_read && if_id_valid;
            id_ex_mem_write  <= id_mem_write && if_id_valid;
            id_ex_mem_to_reg <= id_mem_to_reg && if_id_valid;
            id_ex_is_branch  <= id_is_branch && if_id_valid;
            id_ex_is_call    <= id_is_call && if_id_valid;
            id_ex_is_ret     <= id_is_ret && if_id_valid;
            id_ex_valid      <= if_id_valid;
        end
    end

    // ============================================================
    // EX STAGE - Execute / ALU
    // ============================================================
    wire [31:0] alu_in_a;
    wire [31:0] alu_in_b;

    // Forwarding mux for ALU input A (rs1)
    always @(*) begin
        case (forward_rs1)
            2'b10: alu_in_a = ex_mem_alu_result;
            2'b01: alu_in_a = mem_wb_write_data;
            default: alu_in_a = id_ex_rs1_val;
        endcase
    end

    // Forwarding mux for ALU input B (rs2 or imm)
    reg [31:0] rs2_val_fwd;
    always @(*) begin
        case (forward_rs2)
            2'b10: rs2_val_fwd = ex_mem_alu_result;
            2'b01: rs2_val_fwd = mem_wb_write_data;
            default: rs2_val_fwd = id_ex_rs2_val;
        endcase
    end

    assign alu_in_b = id_ex_i_bit ? id_ex_imm : rs2_val_fwd;

    // ALU operation
    reg [31:0] alu_result;
    reg [3:0]  alu_icc;

    always @(*) begin
        alu_result = 32'h0;
        alu_icc    = icc;

        if (id_ex_valid) begin
            case (id_ex_opcode)
                6'h02: begin // R-type
                    case (id_ex_op3)
                        6'h10: begin // ADDcc
                            alu_result = alu_in_a + alu_in_b;
                            alu_icc = {alu_result==0, $signed(alu_result) < 0, 1'b0, 1'b0};
                        end
                        6'h14: begin // SUBcc
                            alu_result = alu_in_a - alu_in_b;
                            alu_icc = {(alu_in_a-alu_in_b)==0, $signed(alu_in_a) < $signed(alu_in_b), 1'b0, 1'b0};
                        end
                        6'h38: begin // JMPL (call/ret)
                            alu_result = alu_in_a + alu_in_b;
                            alu_icc = icc;
                        end
                        default: begin // other R-type
                            alu_result = alu_in_a + alu_in_b;
                            alu_icc = icc;
                        end
                    endcase
                end
                6'h01: begin // Branch - compute target
                    alu_result = id_ex_pc + (id_ex_imm << 2);
                    alu_icc = icc;
                end
                6'h02: begin // Branch - compute target
                    alu_result = id_ex_pc + (id_ex_imm << 2);
                    alu_icc = icc;
                end
                6'h03: begin // Branch - compute target
                    alu_result = id_ex_pc + (id_ex_imm << 2);
                    alu_icc = icc;
                end
                6'h04: begin // Branch - compute target
                    alu_result = id_ex_pc + (id_ex_imm << 2);
                    alu_icc = icc;
                end
                6'h05: begin // Branch - compute target
                    alu_result = id_ex_pc + (id_ex_imm << 2);
                    alu_icc = icc;
                end
                6'h06: begin // Branch - compute target
                    alu_result = id_ex_pc + (id_ex_imm << 2);
                    alu_icc = icc;
                end
                6'h07: begin // Branch - compute target
                    alu_result = id_ex_pc + (id_ex_imm << 2);
                    alu_icc = icc;
                end
                6'h08: begin // LD
                    alu_result = alu_in_a + alu_in_b;
                    alu_icc = icc;
                end
                6'h09: begin // LD
                    alu_result = alu_in_a + alu_in_b;
                    alu_icc = icc;
                end
                6'h0C: begin // SETHI
                    alu_result = id_ex_imm << 10;
                    alu_icc = icc;
                end
                6'h0E: begin // ST
                    alu_result = alu_in_a + alu_in_b;
                    alu_icc = icc;
                end
                6'h0F: begin // ST
                    alu_result = alu_in_a + alu_in_b;
                    alu_icc = icc;
                end
                default: begin
                    alu_result = alu_in_a;
                    alu_icc = icc;
                end
            endcase
        end
    end

    // Branch target calculation
    wire [31:0] branch_target = id_ex_pc + (id_ex_imm << 2);
    wire ex_branch_taken = id_ex_is_branch && id_ex_valid && branch_cond;

    // Determine destination register
    wire [4:0] ex_rd = id_ex_rd;

    // EX/MEM pipeline register
    always @(posedge clk) begin
        if (rst) begin
            ex_mem_alu_result   <= 32'h0;
            ex_mem_rs2_val      <= 32'h0;
            ex_mem_rd           <= 5'h0;
            ex_mem_opcode       <= 6'h0;
            ex_mem_op3          <= 6'h0;
            ex_mem_reg_write    <= 1'b0;
            ex_mem_mem_read     <= 1'b0;
            ex_mem_mem_write    <= 1'b0;
            ex_mem_mem_to_reg   <= 1'b0;
            ex_mem_icc          <= 4'h0;
            ex_mem_is_branch    <= 1'b0;
            ex_mem_branch_taken <= 1'b0;
            ex_mem_branch_target<= 32'h0;
            ex_mem_pc           <= 32'h0;
            ex_mem_valid        <= 1'b0;
        end else begin
            ex_mem_alu_result   <= alu_result;
            ex_mem_rs2_val      <= rs2_val_fwd;
            ex_mem_rd           <= ex_rd;
            ex_mem_opcode       <= id_ex_opcode;
            ex_mem_op3          <= id_ex_op3;
            ex_mem_reg_write    <= id_ex_reg_write && id_ex_valid;
            ex_mem_mem_read     <= id_ex_mem_read && id_ex_valid;
            ex_mem_mem_write    <= id_ex_mem_write && id_ex_valid;
            ex_mem_mem_to_reg   <= id_ex_mem_to_reg && id_ex_valid;
            ex_mem_icc          <= alu_icc;
            ex_mem_is_branch    <= id_ex_is_branch && id_ex_valid;
            ex_mem_branch_taken <= ex_branch_taken;
            ex_mem_branch_target<= branch_target;
            ex_mem_pc           <= id_ex_pc;
            ex_mem_valid        <= id_ex_valid;
        end
    end

    // ============================================================
    // MEM STAGE - Memory Access
    // ============================================================
    wire [31:0] mem_addr = ex_mem_alu_result;
    wire [31:0] mem_read_data = dmem[mem_addr[9:2]];

    // Memory write (big-endian word)
    always @(posedge clk) begin
        if (ex_mem_mem_write && ex_mem_valid) begin
            dmem[mem_addr[9:2]] <= ex_mem_rs2_val;
        end
    end

    // Determine write data for WB
    reg [31:0] wb_data;
    always @(*) begin
        if (ex_mem_mem_to_reg)
            wb_data = mem_read_data;
        else
            wb_data = ex_mem_alu_result;
    end

    // Handle delay slot branch
    assign delay_taken = ex_mem_branch_taken;
    assign delay_pc = ex_mem_branch_target;
    assign delay_valid = ex_mem_is_branch && ex_mem_valid && ex_mem_branch_taken;

    // MEM/WB pipeline register
    always @(posedge clk) begin
        if (rst) begin
            mem_wb_write_data <= 32'h0;
            mem_wb_rd         <= 5'h0;
            mem_wb_reg_write  <= 1'b0;
            mem_wb_instr      <= 32'h0;
            mem_wb_valid      <= 1'b0;
        end else begin
            // For CALL/JMPL, write PC+4 to %o7
            if (ex_mem_valid && ex_mem_mem_to_reg && (ex_mem_opcode == 6'h03 || 
                (ex_mem_opcode == 6'h02 && ex_mem_op3 == 6'h38))) begin
                mem_wb_write_data <= ex_mem_pc + 32'd4;
            end else if (ex_mem_mem_to_reg) begin
                mem_wb_write_data <= mem_read_data;
            end else begin
                mem_wb_write_data <= ex_mem_alu_result;
            end
            mem_wb_rd        <= ex_mem_rd;
            mem_wb_reg_write <= ex_mem_reg_write && ex_mem_valid;
            mem_wb_instr     <= ex_mem_instr;
            mem_wb_valid     <= ex_mem_valid;
        end
    end

    // ============================================================
    // WB STAGE - Write Back
    // ============================================================
    always @(negedge clk) begin
        if (mem_wb_reg_write && mem_wb_valid && (mem_wb_rd != 5'd0)) begin
            gpr[mem_wb_rd] <= mem_wb_write_data;
        end
        // icc updated in EX stage for ADDcc/SUBcc
    end

    // icc update (EX stage)
    always @(posedge clk) begin
        if (rst) begin
            icc <= 4'h0;
        end else if (id_ex_valid && (id_ex_opcode == 6'h02) && 
            (id_ex_op3 == 6'h10 || id_ex_op3 == 6'h14)) begin
            icc <= alu_icc;
        end
    end

    // ============================================================
    // INITIALIZATION
    // ============================================================
    initial begin
        gpr[0] = 32'h0;  // %g0 hardwired to 0
        gpr[31] = 32'h0000_0100; // %i7 return address marker
        for (integer i = 1; i < 31; i = i + 1)
            gpr[i] = 32'h0;
        icc = 4'h0;
        for (integer i = 0; i < IMEM_DEPTH; i = i + 1)
            imem[i] = 32'h0;
        for (integer i = 0; i < DMEM_DEPTH; i = i + 1)
            dmem[i] = 32'h0;
    end

    // ============================================================
    // OUTPUTS
    // ============================================================
    assign pc_o   = pc;
    assign gpr_v0 = gpr[8]; // %o0 = register 8
    assign icc_o  = icc;
    assign done_o = (pc == 32'h0) && (if_id_valid == 1'b0) && (id_ex_valid == 1'b0);

    // Debug outputs
    assign dbg_pc_write      = pc_write;
    assign dbg_stall         = stall;
    assign dbg_if_id_write   = if_id_write;
    assign dbg_id_ex_flush   = id_ex_flush;
    assign dbg_id_ex_valid   = id_ex_valid;
    assign dbg_ex_mem_valid  = ex_mem_valid;
    assign dbg_mem_wb_valid  = mem_wb_valid;
    assign dbg_id_ex_rd      = id_ex_rd;
    assign dbg_ex_mem_rd     = ex_mem_rd;
    assign dbg_wb_write      = mem_wb_reg_write && mem_wb_valid && (mem_wb_rd != 5'd0);
    assign dbg_wb_rd         = mem_wb_rd;
    assign dbg_wb_data       = mem_wb_write_data;
    assign dbg_wb_instr      = mem_wb_instr;

endmodule